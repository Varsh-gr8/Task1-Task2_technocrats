import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge
import cv2
import numpy as np
class ObjectFollower(Node):
    def __init__(self):
        super().__init__('object_follower')
        self.subscriber=self.create_subscription(Image,'image_raw',self.callback,10)
        self.publisher=self.create_publisher(Twist,'/turtle1/cmd_vel',10)
        self.br=CvBridge()
    def callback(self,data):
        frame=self.br.imgmsg_to_cv2(data,"bgr8")
        hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
        lower_red=np.array([0,120,70])
        upper_red=np.array([10,255,255])
        mask1=cv2.inRange(hsv,lower_red,upper_red)
        lower_red=np.array([170,120,70])
        upper_red=np.array([180,255,255])
        mask2=cv2.inRange(hsv,lower_red,upper_red)
        mask=mask1+mask2
        contour,_=cv2.findContours(mask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
        twist=Twist()
        if contour:
            c=max(contour,key=cv2.contourArea)
            M=cv2.moments(c)
            if M['m00']>0:
                cx=int(M['m10']/M['m00'])
                width=frame.shape[1]
                center=width//2
                if cx<center-50:
                    twist.angular.z=1.0
                elif cx>center+50:
                    twist.angular.z=-1.0
                else:
                    twist.linear.x=2.0
        
        self.publisher.publish(twist)
def main(args=None):
     rclpy.init(args=args)
     node=ObjectFollower()
     rclpy.spin(node)
     node.destroy_node()
     rclpy.shutdown()

