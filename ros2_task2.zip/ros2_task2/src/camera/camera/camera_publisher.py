import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
class CameraPublisher(Node):
    def __init__(self):
        super().__init__('camera_publisher')
        self.publisher_=self.create_publisher(Image,'image_raw',10)
        self.br=CvBridge()
        self.cap=cv2.VideoCapture(0)
        self.timer=self.create_timer(0.1,self.callback)
    def callback(self):
        ret,frame=self.cap.read()
        if ret:
            msg=self.br.cv2_to_imgmsg(frame,"bgr8")
            self.publisher_.publish(msg)
def main(args=None):
    rclpy.init(args=args)
    node=CameraPublisher()
    rclpy.spin(node)
    node.cap.release()
    node.destroy_node()
    rclpy.shutdown()
