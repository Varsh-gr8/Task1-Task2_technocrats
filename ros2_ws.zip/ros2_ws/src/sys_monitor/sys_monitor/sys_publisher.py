
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import psutil

class SystemMonitor(Node):
    def __init__(self):
        super().__init__("sys_monitor_node")
        self.cpu_pub=self.create_publisher(Float32,'CPU',10)
        self.temp_pub=self.create_publisher(Float32,'temp',10)
        self.timer=self.create_timer(2.0,self.pub)
    def pub(self):
        msg_cpu=Float32()
        cpu_usage=psutil.cpu_percent()
        msg_cpu.data=cpu_usage
        self.cpu_pub.publish(msg_cpu)
        self.get_logger().info(f'CPU percent: {cpu_usage}%')
        temps=psutil.sensors_temperatures()
        temp_val=0.0
        if 'coretemp' in temps:
            temp_val=temps['coretemp'][0].current
        elif temps:
            for val in temps.values():
                temp_val=val[0].current
                break
        msg_temp=Float32()
        msg_temp.data=temp_val
        self.temp_pub.publish(msg_temp)
        self.get_logger().info(f'temperature: {temp_val}C')
def main(args=None):
    rclpy.init(args=args)
    node=SystemMonitor()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
if __name__=='__main__':
    main()
