import rclpy
from rclpy.node import Node
class Utility (Node):
    def __init__(self):
        super().__init__('util_node')
        self.timer=self.create_timer(5.0,self.check_stats)
    def check_stats(self):
        cpu_pubs=self.count_publishers('/CPU')
        cpu_subs=self.count_subscribers('/CPU')
        temp_pubs=self.count_publishers('/temp')
        temp_subs=self.count_subscribers('/temp')
        node_names=self.get_node_names()
        total_nodes=len(node_names)
        self.get_logger().info(f"---System Info---")
        self.get_logger().info(f'count of cpu publishers: {cpu_pubs}, count of CPU subscribers: {cpu_subs}')
        self.get_logger().info(f'count of temp publishers: {temp_pubs}, count of temp subscribers: {temp_subs}')
        self.get_logger().info(f'Total active nodes: {total_nodes}')
def main(args=None):
    rclpy.init(args=args)
    node=Utility()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
if __name__=='__main__':
    main()
