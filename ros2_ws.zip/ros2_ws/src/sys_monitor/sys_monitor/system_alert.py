import rclpy
from std_msgs.msg import Float32
from rclpy.node import Node
class SystemAlert(Node):
    def __init__(self):
        super().__init__('system_alert_node')
        self.cpu_sub=self.create_subscription(Float32,'CPU',self.cpu_callback,10)
        self.temp_sub=self.create_subscription(Float32,'temp',self.temp_callback,10)
    def cpu_callback(self,msg):
        cpu=msg.data
        if 0.5<=cpu<=0.99:
            self.get_logger().warn('Low CPU USAGE')
        elif 1.0<=cpu<=1.99:
            self.get_logger().info('Normal CPU USAGE')
        elif cpu>=2.0:
            self.get_logger().fatal('Critical CPU USAGE')
            rclpy.shutdown()
    def temp_callback(self,msg):
        temp=msg.data
        if temp<=19:
            self.get_logger().warn('Low Temperature')
        elif 20<=temp<59:
            self.get_logger().info('Normal Temperature')
        elif temp>=60:
            self.get_logger().fatal('Time to buy a new Pi')
            rclpy.shutdown()
def main(args=None):
    rclpy.init(args=args)
    node=SystemAlert()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
if __name__=='__main__':
    main()

